//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Hexa2.rc
//
#define IDI_ICON1                       103
#define IDR_MENU1                       104
#define IDR_ACCELERATOR1                106
#define IDB_BITMAP1                     107
#define IDB_BITMAP2                     108
#define IDB_BITMAP3                     109
#define IDB_BITMAP4                     110
#define IDB_BITMAP5                     111
#define IDB_BITMAP6                     112
#define IDB_BITMAP7                     113
#define IDB_BITMAP8                     114
#define IDB_BITMAP9                     115
#define IDB_BITMAP10                    116
#define IDB_BITMAP11                    117
#define IDB_BITMAP12                    118
#define IDM_GAME_START                  40001
#define IDM_GAME_PAUSE                  40002
#define IDM_GAME_QUIET                  40003
#define IDM_GAME_EXIT                   40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        122
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
